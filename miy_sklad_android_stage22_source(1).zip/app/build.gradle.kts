plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "ua.miy.sklad"; compileSdk = 35
 defaultConfig { applicationId = "ua.miy.sklad"; minSdk = 23; targetSdk = 35; versionCode = 5; versionName = "3.1-test" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
