package ua.miy.sklad

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.net.Uri
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<android.net.Uri>>? = null
    private var backupJson: String? = null
    private val pickJson = 1001
    private val saveJson = 1002

    inner class BackupBridge {
        @JavascriptInterface fun saveBackup(json: String) {
            runOnUiThread {
                // Keep a single pending backup; a second tap must not replace its data.
                if (backupJson != null) {
                    Toast.makeText(this@MainActivity, "Збереження копії вже відкрите", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                if (json.isBlank()) {
                    Toast.makeText(this@MainActivity, "Резервна копія порожня", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                backupJson = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "miy_sklad_backup.json")
                }
                try { startActivityForResult(intent, saveJson) }
                catch (e: Exception) {
                    backupJson = null
                    Toast.makeText(this@MainActivity, "Не вдалося відкрити вибір файлу", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        // The bundled inventory is trusted local code, not arbitrary web content.
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true // Required for file:///android_asset/index.html
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(BackupBridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                // No navigation away from the packaged, offline inventory UI.
                return request?.url?.toString() != "file:///android_asset/index.html"
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, callback: ValueCallback<Array<android.net.Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                return try {
                    startActivityForResult(intent, pickJson)
                    true
                } catch (e: Exception) {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = null
                    Toast.makeText(this@MainActivity, "Не вдалося відкрити файли", Toast.LENGTH_LONG).show()
                    true
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickJson) {
            fileCallback?.onReceiveValue(if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null)
            fileCallback = null
        } else if (requestCode == saveJson) {
            if (resultCode == RESULT_OK && data?.data != null && backupJson != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { out ->
                        out.write(backupJson!!.toByteArray(Charsets.UTF_8))
                    } ?: error("Не вдалося відкрити файл")
                    Toast.makeText(this, "Копію збережено", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Помилка збереження: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            backupJson = null
        }
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        web.removeJavascriptInterface("AndroidBridge")
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Back navigation for embedded WebView")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
