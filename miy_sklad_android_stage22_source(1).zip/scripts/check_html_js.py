#!/usr/bin/env python3
"""Syntax-check every inline JavaScript block embedded in the Android asset."""
import re, subprocess, tempfile
from pathlib import Path
html=Path('app/src/main/assets/index.html').read_text(encoding='utf-8')
scripts=re.findall(r'<script(?:\s[^>]*)?>(.*?)</script\s*>',html,re.S|re.I)
assert scripts, 'No inline JavaScript found'
for i,js in enumerate(scripts):
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/f'inline_{i}.js'
        p.write_text(js,encoding='utf-8')
        subprocess.run(['node','--check',str(p)],check=True)
print(f'PASS: {len(scripts)} inline JavaScript blocks passed syntax checks')
