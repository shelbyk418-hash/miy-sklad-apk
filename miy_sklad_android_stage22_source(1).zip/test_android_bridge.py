from pathlib import Path
from playwright.sync_api import sync_playwright
import json, threading, http.server, functools
html=Path(__file__).parent.joinpath('app/src/main/assets/index.html').read_text()
results=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844})
 page.add_init_script("window.__saved=[];window.AndroidBridge={saveBackup(json){window.__saved.push(json)}};")
 page.on('dialog',lambda dialog:dialog.accept())
 errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
 page.goto('about:blank')
 pre="<script>window.__storage=null;Object.defineProperty(window,'localStorage',{value:{getItem(){return window.__storage},setItem(k,v){window.__storage=v}}});window.__saved=[];window.AndroidBridge={saveBackup(json){window.__saved.push(json)}};</script>"
 page.set_content(html.replace('<script>',pre+'<script>',1))
 def test(label,func):
  try:func();results.append({'test':label,'passed':True});print('PASS',label)
  except Exception as e:results.append({'test':label,'passed':False,'error':str(e)});print('FAIL',label,e)
 def receipt():
  page.evaluate("db.sills.push({id:'TEST1',name:'OpenTeck Білий 700',len:6000,condition:'ok',note:''});save('Тестове надходження','1 шт')")
  assert len(page.evaluate('db.sills'))==1
 test('Save test inventory to app storage',receipt)
 def bridge():
  page.locator('#export').evaluate('(x)=>x.click()')
  saved=page.evaluate('window.__saved');assert len(saved)==1
  exported=json.loads(saved[0]);assert len(exported['sills'])==1
  assert exported['sills'][0]['len']==6000
 test('Android bridge receives valid full JSON backup',bridge)
 def import_back():
  backup=json.loads(page.evaluate('window.__saved[0]'))
  backup['sills'][0]['len']=4000
  page.locator('#import').set_input_files({'name':'backup.json','mimeType':'application/json','buffer':json.dumps(backup).encode()})
  assert page.evaluate('db.sills[0].len')==4000
 test('Import via Android-style file picker input',import_back)
 test('No JavaScript runtime errors',lambda:(_ for _ in ()).throw(Exception(str(errors))) if errors else None)
 b.close()
Path(__file__).parent.joinpath('bridge_test_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
if not all(r['passed'] for r in results):raise SystemExit(1)
