from pathlib import Path
from playwright.sync_api import sync_playwright
html=Path('app/src/main/assets/index.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(); page.on('dialog',lambda d:(print('DIALOG',d.message),d.accept())); errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html.replace('<script>','<script>window.__storage=null;Object.defineProperty(window,"localStorage",{value:{getItem(){return window.__storage},setItem(k,v){window.__storage=v}}});</script><script>',1))
 def js(s):return page.evaluate(s)
 def check(n,v):
  assert v,n
  print('PASS',n)
 js("document.getElementById('sname').value='Sauberg Білий Матовий 700';document.getElementById('slen').value='6000';document.getElementById('sqty').value='8';document.getElementById('sadd').click()")
 check('8 identical sills received',js('db.sills.length===8'))
 js("document.getElementById('damageQty').value='2';document.querySelectorAll('#damageEdit button')[1].click();document.getElementById('damageEditNote').value='тест';document.getElementById('damageSave').click()")
 check('2 damaged 6 remain good',js("db.sills.filter(x=>x.condition!=='good').length===2 && db.sills.filter(x=>x.condition==='good').length===6"))
 js("document.getElementById('undogo').click()")
 check('undo restores all eight',js("db.sills.length===8 && db.sills.every(x=>x.condition==='good')"))
 js("document.getElementById('longname').value=db.sills[0].name;document.getElementById('longname').dispatchEvent(new Event('change'));document.getElementById('longwidth').value='350';document.getElementById('longlen').value='5000';document.getElementById('longgo').click()")
 check('700 splits 350+350 and keeps 1000mm remainder',js("db.sills.length===10 && db.sills.filter(x=>x.len===5000&&x.name.endsWith('350')).length===2 && db.sills.some(x=>x.len===1000&&x.name.endsWith('700'))"))
 js("document.getElementById('shipname').value=db.sills.find(x=>x.name.endsWith('350')).name;document.getElementById('shipname').dispatchEvent(new Event('change'));document.getElementById('shipqty').value='2';document.getElementById('sremove').click()")
 check('ship 2 pieces deducts 2',js('db.sills.length===8 && db.sills.every(x=>!x.name.endsWith("350"))'))
 js("document.getElementById('scutname').value=db.sills.find(x=>x.len===1000).name;document.getElementById('scutname').dispatchEvent(new Event('change'));document.getElementById('scutlen').value='400';document.getElementById('scutqty').value='2';document.getElementById('scutgo').click()")
 check('crosscut 1000 into 2x400 keeps 200',js('db.sills.length===8 && db.sills.some(x=>x.len===200) && !db.sills.some(x=>x.len===1000)'))
 check('no browser errors',not errors)
 b.close()
