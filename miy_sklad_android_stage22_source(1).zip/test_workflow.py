from pathlib import Path
from playwright.sync_api import sync_playwright
import json
html=Path('app/src/main/assets/index.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844})
 page.on('dialog',lambda d:d.accept())
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 pre="<script>window.__storage=null;Object.defineProperty(window,'localStorage',{value:{getItem(){return window.__storage},setItem(k,v){window.__storage=v}}});</script>"
 page.set_content(html.replace('<script>',pre+'<script>',1))
 def js(x):return page.evaluate(x)
 def setv(i,v):js("(document.getElementById(%r).value=%r)"%(i,str(v)))
 def check(label,assertion):
  if not assertion:raise AssertionError(label)
  print('PASS',label)
 js("db.coils.push({id:'Б-001',color:'Білий',shade:'',thick:.45,width:1250,left:90});save('test','coil')")
 page.locator('[data-tab=cut]').click()
 setv('widths','90+90+200');setv('run',30);js("document.getElementById('cutgo').click()")
 check('Coil loses only 30 m for three strips',js("db.coils[0].left===60 && db.strips.length===3 && db.strips.every(s=>s.len===30)"))
 setv('run',30);js("document.getElementById('cutgo').click()")
 check('Second pass leaves 30 m',js('db.coils[0].left===30 && db.strips.length===6'))
 setv('run',30);js("document.getElementById('cutgo').click()")
 check('Third pass closes coil',js('db.coils[0].left===0 && db.strips.length===9'))
 check('Zero coil absent from cutter',js("![...document.querySelector('#cutcoil').options].some(o=>o.value==='Б-001')"))
 setv('instripcolor','Коричневий');setv('instripwidth',180);setv('instriplen',16);setv('instripqty',2);js("document.getElementById('instripgo').click()")
 check('Two ready strip rolls received independently',js('db.strips.length===11 && db.strips.filter(s=>s.width===180&&s.len===16).length===2 && db.coils[0].left===0'))
 setv('reslitSource',js("db.strips.find(s=>s.width===180).id"));setv('reslitWidths','90+90');setv('reslitLength',5);js("document.getElementById('reslitGo').click()")
 check('Reslit 5m of 180 into 2x90, preserve 11m of 180',js('db.strips.filter(s=>s.width===90&&s.len===5).length===2 && db.strips.some(s=>s.width===180&&s.len===11) && db.strips.some(s=>s.width===180&&s.len===16)'))
 js("document.getElementById('undogo').click()")
 check('Undo restores reslit inventory',js('db.strips.filter(s=>s.width===90&&s.len===5).length===0 && db.strips.filter(s=>s.width===180&&s.len===16).length===2'))
 check('No browser runtime errors',not errors)
 b.close()
